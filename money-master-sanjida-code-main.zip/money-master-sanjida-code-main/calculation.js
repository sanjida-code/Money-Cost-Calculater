// handle cost button event
    document.getElementById('cost-button').addEventListener('click', function () {
    // get the salary amount 
    const salaryInput = document.getElementById('salary-input');
    const newSalaryAmountText = salaryInput.value;
    const newSalaryAmount = parseFloat(newSalaryAmountText);

    // get the amount cost    
    const foodCostInput = document.getElementById('foodcost-input');
    const newFoodCostAmountText = foodCostInput.value;
    const newFoodCostAmount = parseFloat(newFoodCostAmountText);
    if(newFoodCostAmountText<0 ){
        document.getElementById("cost-button").innerHTML = "Please food cost is Positive Value!"
    }

    const rantCostInput = document.getElementById('rantcost-input');
    const newRantCostAmountText = rantCostInput.value;
    const newRantCostAmount = parseFloat(newRantCostAmountText);
    if(newRantCostAmount<0){
        document.getElementById("cost-button").innerHTML = "Please Rant cost is Positive Value!"
    }

    const clothesCostInput = document.getElementById('clothescost-input');
    const newClothesCostAmountText = clothesCostInput.value;
    const newClothesCostAmount = parseFloat(newClothesCostAmountText);
    if(newClothesCostAmount<0){
        document.getElementById("cost-button").innerHTML = "Please Clohtes cost is Positive Value!"
    }

    // update cost total
     const costTotal = document.getElementById('cost-total');
     const newCostTotal = newFoodCostAmount + newRantCostAmount + newClothesCostAmount;
     costTotal.innerText = newCostTotal;
    
    // update account balance 
    const balanceTotal = document.getElementById('balance-total');
    const newBalanceTotal = newSalaryAmount - newCostTotal ;

    balanceTotal.innerText = newBalanceTotal;
});

// handle save button event
document.getElementById('save-button').addEventListener('click', function () {
    // get the save salary amount 
    const salaryInput = document.getElementById('salary-input');
    const newSalaryAmountText = salaryInput.value;
    const newSalaryAmount = parseFloat(newSalaryAmountText);

    const saveInput = document.getElementById('save-input');
    const newSaveAmountText = saveInput.value;
    const newSaveAmount = parseFloat(newSaveAmountText);
    const saveTotal = (newSalaryAmount * newSaveAmount)/100;

// save  total balance
    const newSaveTotal = document.getElementById('save-total');        
    newSaveTotal.innerText = saveTotal;
    
//new balance after save
    const balanceTotal = document.getElementById('balance-total');

    const newLastBalanceTotal = document.getElementById('new-balance-total'); 
    const balanceTotalAfterSave= balanceTotal - saveTotal;

    newLastBalanceTotal.innerText = balanceTotalAfterSave;

});
